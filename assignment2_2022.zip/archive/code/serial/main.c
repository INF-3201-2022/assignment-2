#include <stdio.h>
#include <stdlib.h>
#include "lib/bmp.h"
#include <math.h>
#include <string.h>

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) < (b) ? (b) : (a))
#define GP(X,Y) GetPixel(img, width, height,(X),(Y))


/**
 * @brief Convert an image to grayscale
 * 
 * @param img 
 * @param width 
 * @param height 
 */
void ImageToGrayscale(RGB *img, const int width, const int height){
    for(int i=0;i<width*height;i++){
        char grayscale=img[i].red*0.3+img[i].green*0.59+img[i].blue*0.11;
        img[i].red=grayscale;
        img[i].green=grayscale;
        img[i].blue=grayscale;
    }
}

/**
 * @brief Return a pixel no matter the coordinate
 * 
 * @param img 
 * @param width 
 * @param height 
 * @param x 
 * @param y 
 * @return RGB 
 */
RGB GetPixel(RGB *img, const int width, const int height, const int x, const int y){
    if(x<0 || y<0 || x>=width || y >=height){
        RGB pixel;
        pixel.red=0;
        pixel.green=0;
        pixel.blue=0;
        return(pixel);
    }
    return(img[x+y*width]);
}

void ApplySobel(RGB *img, const int width, const int height){}

void ApplyBoxBlur(RGB *img, const int width, const int height){}


int main(){
    const char *marguerite="marguerite.bmp";
    const char *outsobel="sobel.bmp";
    const char *outbblur="boxblur.bmp";

    // Get image dimensions
    int width,height;
    GetSize(marguerite,&width, &height);

    // Init memory
    RGB *sobel=malloc(sizeof(RGB)*width*height);
    RGB *bblur=malloc(sizeof(RGB)*width*height);

    // Load images
    LoadRegion(marguerite,0,0, width,height,sobel);
    LoadRegion(marguerite,0,0, width,height,bblur);

    // Apply filters
    ApplySobel(sobel,width,height);
    ApplyBoxBlur(bblur,width,height);

    // Save images
    CreateBMP(outsobel,width,height);
    WriteRegion(outsobel,0,0,width, height,sobel);
    CreateBMP(outbblur,width,height);
    WriteRegion(outbblur,0,0,width, height,bblur);

    // Free memory
    free(sobel);
    free(bblur);

    return(0);
}
